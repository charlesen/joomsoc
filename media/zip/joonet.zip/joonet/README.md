# Joonet - Social Network Component for Joomla!

Joonet is a free and complete social network for Joomla! CMS. Just like Jomsocial, but for FREE !!
I built this component as a response of commercial versions of kind of components.

### How it works
Simply install the extensions on Joomla! and it's done. You can also customize the component to fit your goals


### Authors and Contributors
Charles EDOU NZE [@charlesen](https://twitter.com/charlesen7)

### Support or Contact
Having trouble with Joonet ? Check out my [website](https://charlesen.fr) and I’ll help you sort it out.
