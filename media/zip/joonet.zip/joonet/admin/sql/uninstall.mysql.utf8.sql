DROP TABLE IF EXISTS `#__joonet`;
DROP TABLE IF EXISTS `#__joonet_user_details`;
DROP TABLE IF EXISTS `#__joonet_socialauth`;